a = int(input("Informe um numero"))
b = int(input("Informe outro numero"))

if a >10 and b <10:
    print("um dos numeros é maior que 10 e outro menor")
else:
    print("Ambos os numeros são menores ou maiores que 10")