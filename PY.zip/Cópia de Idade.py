Nome = str(input("Informe o nome"))
Ano = int(input("Informe o ano do nascimento"))
print(Nome,"Possui ou ira fazer",2023 - Ano,"anos")