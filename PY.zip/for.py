for i in range (1,103,2):
    print (i)