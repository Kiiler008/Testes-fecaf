a = int(input("Informe um numero A"))
b = int(input("Informe outro numero que será B"))
if a>b:
    print (a,"A é maior que B")
else:
    print(b,"B é maior que A")