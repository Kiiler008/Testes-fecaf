#Teste
K = float(input("Informe a distancia em Kilometros"))
C = 0.61371
M = K*C
print('%0.2f Kilometros são %0.2f Milhas'%(K,M))
