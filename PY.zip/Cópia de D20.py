#Teste
import random
D =(random.randint(0,20))
print(D)
if D == 0:
    print("Erro crítico")
if D == 20:
    print("Acerto crítico")
