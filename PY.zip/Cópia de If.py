Nota = float(input("Informe a nota do aluno:"))
if Nota ==10:
    print("Aluno aprovado com honras")
elif Nota >=6.51:
    print("Auno aprovado")
elif Nota == 1:
    print("Aluno reprovado de imediato")
elif Nota <=4.51:
    print("Aluno reprovado")
else:
    print("Aluno de recuperação")
