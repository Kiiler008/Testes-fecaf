package Teste2;

public class testedata {
	public static void main(String[]args) {
		Data d1 = new Data(27,10,2002);
		Data d2 = new Data(17,8,2023);
		System.out.println("Data 1:" + d1);
		System.out.println("Data 2:" + d2);
		d2.trocarCom(d1);
		System.out.println("Após a troca");
		System.out.println("Data 1:" + d1);
		System.out.println("Data 2:" + d2);
	}

}
