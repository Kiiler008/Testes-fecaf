package exercicos;

import java.util.Scanner;

public class Ex08 {
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        
        float vhora, htrab,salario;

        System.out.print("informe o valor que você ganha por hora: ");
        vhora = scanner.nextFloat();

        System.out.print("informe o número de horas trabalhadas no mês: ");
        htrab = scanner.nextFloat();

        salario = vhora * htrab;

        System.out.println("O seu salário no mês é: " + salario);

        scanner.close();
    }
}
