package ex;

import java.util.Scanner;

public class Ex02 {
	public static void main(String[] args) {
	
	int num1;
	
	Scanner input = new Scanner(System.in);
	
	System.out.println("Informe o numero que será analisado: ");
	num1 = input.nextInt();
	
	System.out.println(" O numero informado foi" + num1);
	
	}

}
