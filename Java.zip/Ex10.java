package ex;

import java.util.Scanner;

public class Ex10 {public static void main(String[] args) {
	
	float f,c;
	
Scanner input = new Scanner(System.in);
	
	System.out.println("Informe a temperatura em Celcius: ");
	c = input.nextFloat();
	
	f =(c *9/5) + 32 ;
	System.out.println(c + " Em Celcious equivalem em Fahrenheit "+f);
}
}