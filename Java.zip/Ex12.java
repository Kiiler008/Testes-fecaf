package ex;

import java.util.Scanner;

public class Ex12 {
	public static void main(String[] args) {
		
		float alt,pesoid;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe sua altura: ");
		alt = input.nextFloat();
		
		pesoid =(int) ((72.7 * alt) - 58);
		
		System.out.println(pesoid);
		
		
}
}