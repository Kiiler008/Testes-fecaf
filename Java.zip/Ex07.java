package exercicos;

import java.util.Scanner;

public class Ex07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        double lado,area,darea;
        
        System.out.print("Digite o lado do quadrado: ");
        lado = scanner.nextDouble();

        area = lado * lado;
        darea = 2 * area;

        System.out.println("A área do quadrado é: " + area);
        System.out.println("O dobro da área do quadrado é: " + darea);

        scanner.close();
    }
}
