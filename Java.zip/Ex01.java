package exercicos;

import java.util.Scanner;

public class Ex01 {
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt();

        if (numero % 5 == 0 && numero % 3 == 0) {
            System.out.println("O número é divisível por 5 e por 3 ao mesmo tempo.");
        } else {
            System.out.println("O número não é divisível por 5 e por 3 ao mesmo tempo.");
        }

        scanner.close();
}}