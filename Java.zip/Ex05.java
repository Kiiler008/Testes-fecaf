package ex;

import java.util.Scanner;

public class Ex05 {
	public static void main(String[] args) {
		float m,c;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe a distancia em metros: ");
		m = input.nextFloat();
		
		c = m * 100;
		System.out.println(m + " Em Centimetros equivalem a "+c);
}
}