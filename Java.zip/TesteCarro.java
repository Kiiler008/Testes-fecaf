package teste37944;

public class TesteCarro {

	public static void main(String[] args) {
		Carro carro1 = new Carro("Honda","Cinza","JJBA04", 4);
		carro1.ExibirInformacoes();
		System.out.println(carro1.getTipo());
		System.out.println(carro1.getCor());
		System.out.println(carro1.getPlaca());
		System.out.println(carro1.getQtdPortas());
	}
}
