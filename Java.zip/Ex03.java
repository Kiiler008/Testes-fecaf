package ex;

import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {

		int num1, num2;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe o primeiro numero que será somado: ");
		num1 = input.nextInt();
		
		System.out.println("Informe o segundo numero que será somado: ");
		num2 = input.nextInt();
		
		System.out.println("O valor da soma é ");
		System.out.println(num1 + num2);
		
	}

}
