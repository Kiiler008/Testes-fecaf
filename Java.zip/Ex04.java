package ex;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {

		float nota1, nota2, nota3, nota4,media;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe a primeira nota: ");
		nota1 = input.nextFloat();
		
		System.out.println("Informe a segunda nota:  ");
		nota2 = input.nextFloat();
		
		System.out.println("Informe a teceira nota:  ");
		nota3 = input.nextFloat();
		
		System.out.println("Informe a ultima nota:  ");
		nota4 = input.nextFloat();
		media = (nota1 + nota2 + nota3 + nota4) /4 ;
		
		System.out.println(media + "Foi a média final do aluno");
}
	}